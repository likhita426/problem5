/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//series program//
//write a program to print the summated value of all even numbers and all even numbers from 21 to 60//
#include <stdio.h>

int main()
{
    int i,s=0;
    
        for(i=21;i<=60;i++)
        {
            if(i%2==0)
            {
                printf("The even numbers between 21 and 60 are: %d \n",i);
            }
            s=s+i;
            printf("The sum of all even numbers between 21 and 60: %d \n ",s);
            
        }
    
    
}
